from models.product import Product
from models.interfaces.canBeShipped import CanBeShipped

class PhysicalProduct(Product, CanBeShipped):
    def __init__(self, product_id, name, price, stock_quantity, supplier, weight):
        super().__init__(product_id, name, price, stock_quantity, supplier) # inherits attributes from parent class
        self.weight = weight # am attribute that only a physical product has

    def display_info(self):
        parent_info = super().__str__() # inherits the __str__() method from the parent class
        return parent_info + f"Weight: {self.weight}kg"

    def get_fulfilment_info(self):
        return f"Physical produts are shipped."
    
    def get_shipping_weight(self):
        return f"The shipping weight is {self.weight}kg."